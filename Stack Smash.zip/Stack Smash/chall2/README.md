# CHALL 2
- `gcc -o chall2 -no-pie -fno-stack-protector -z execstack main.c -static`
- ASLR should be OFF
- Will use port 1338
- Get shell: Buffer Overflow to overwrite return address and hijack control flow -> ret2shellcode with `jmp rax` gadget to bypass ASLR.
