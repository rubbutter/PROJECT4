#!/bin/bash

IMAGE_NAME=chall1

docker rm -f $(sudo docker ps -a | awk -v i="^$IMAGE_NAME.*" '{if($2~i){print$1}}');
docker build -t ${IMAGE_NAME} .
docker run -d --restart=always -p 2223:2223 ${IMAGE_NAME}
