# CHALL 5
- `gcc ./chall5.c -z execstack -fno-pie -no-pie -o chall5`
- Leak canary: negative OOB access on an `int` array on the stack to leak a residual canary somewhere on the higher part of the stack.
- Get shell: unlimited write on stack buffer -> overwrite return address to print flag function.
- Slides: https://docs.google.com/presentation/d/1ErnCBlB8PLFVR6mCAQm-xEEYc3bJ8zgeMGavoddUm6w/edit?usp=sharing
