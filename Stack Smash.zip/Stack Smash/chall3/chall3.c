#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>

int main(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    
    printf("> ");
    char* shellcode = mmap(0, 0x2000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANONYMOUS, 0, 0);
    int len = read(0, shellcode, 0x2000);
    for (int i = 0; i < len; i++) {
        if ((shellcode[i] & 1) != (i % 2)) {
            puts("bad shellcode!");
            return 1;
        }
    }
    ((void (*)(long long))shellcode)(0);
    return 0;
}
