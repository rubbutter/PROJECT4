#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char echo_buf[2048];
char name[40];

void init() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void echo(){
    char buf[40];
    memset(buf, 0, 40);
    
    printf("Your message: ");
    scanf("%s", buf);

    sprintf(echo_buf, "echo \"%ld\"", strlen(buf));
    system(echo_buf);

    return;
}

int main(void){
    init();

    puts("Welcome to my measuring system v1.0");
    puts("I'll always tell you how long your messages are");
    puts("What's your name?");
    printf("> ");
    scanf("%40s", name);

    while (1) {
        echo();
    }
}

