#!/bin/bash

IMAGE_NAME=chall3

docker rm -f $(sudo docker ps -a | awk -v i="^$IMAGE_NAME.*" '{if($2~i){print$1}}');
docker build -t ${IMAGE_NAME} .
docker run -d --restart=always -p 2225:2225 ${IMAGE_NAME}
