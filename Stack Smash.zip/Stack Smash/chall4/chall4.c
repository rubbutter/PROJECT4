#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>

void getflag(void){
    char *flag_file = "./flag.txt";
    char *flag;
    struct stat st;
    int fd;

    stat(flag_file, &st);
    fd = open(flag_file, O_RDONLY);

    flag = calloc(1, st.st_size);
    read(fd, flag, st.st_size);

    write(1, flag, st.st_size);
}

void vuln(void){
    unsigned size;
    char buf[40];
    puts("How many bytes do you want to read?");
    scanf("%u", &size);
    puts("Send your data");
    read(0, buf, size);
}

int main(void){
    while(1){
        if(!fork()){
            vuln();
            puts("child exiting...");
            exit(0);
        } else {
            wait(NULL);
        }
    }
}