# CHALL 6
- `gcc ./chall6.c -Wl,-z,relro,-z,now -fno-stack-protector -fno-pie -no-pie -o chall6`
- Simple ROP without randomization and `system()` is already imported.
