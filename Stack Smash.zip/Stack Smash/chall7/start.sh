#!/bin/bash

IMAGE_NAME=chall7

docker rm -f $(sudo docker ps -a | awk -v i="^$IMAGE_NAME.*" '{if($2~i){print$1}}');
docker build -t ${IMAGE_NAME} .
docker run -d --restart=always -p 2229:2229 ${IMAGE_NAME}
