#include <stdio.h>

void vuln(){
    char buf[40];
    gets(buf);
}

int main(void){
    puts("Week 1 - stack attacks and shellcode (challenge 2)");
    puts("Gimme ur bytes plz");
    vuln();
    puts("Thank you!");
    return 0;
}
