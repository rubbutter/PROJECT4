#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void init() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void echo(){
    char buf[40];
    memset(buf, 0, 40);
    
    printf("Your message: ");
    scanf("%s", buf);

    printf("%ld\n", strlen(buf));

    return;
}

int main(void){
    init();
    
    puts("Welcome to my measuring system v2.0");
    puts("I'll always tell you how long your messages are");
    puts("Please don't pwn me again");

    while (1) {
        echo();
    }
}

