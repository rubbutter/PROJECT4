# CHALL 1
- `gcc ./chall1.c -z execstack -fno-stack-protector -fno-pie -no-pie -o chall1`
- Introductory shellcode challenge to introduce different ways to get/generate/write a shellcode.
