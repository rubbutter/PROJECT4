#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

void init() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void flag() {
    char buf[100];
    int fd = open("./flag.txt", O_RDONLY);
    read(fd, buf, 100);
    write(1, buf, 100);
}

void menu() {
    puts("1. Add new contact");
    puts("2. View contact");
    puts("3. Exit");
    printf("> ");
}

int main(int argc, char* argv[]) {
    int choice;
    int index;
    int number;
    int count = 0;
    int array[10];
    char name[32];
    
    init();
    memset(array, 0, sizeof(int) * 10);
    memset(name, 0, 32);

    printf("Welcome to phonebook app\n");
    printf("Please enter your name: ");
    read(0, name, 31);
    
    while (1) {
        menu();
        scanf("%d", &choice);

        if (choice == 1) {
            if (count == 10) {
                puts("No more slots");
            } else {
                printf("Enter a number: ");
                scanf("%d", &number);
                array[count] = number;
                count++;
            }

        } else if (choice == 2) {
            printf("Choose index (0 - 9): ");
            scanf("%d", &index);
            if (index > 9) {
                puts("Invalid index");
            } else {
                printf("The number is %d\n", array[index]);
            }

        } else if (choice == 3) {
            printf("Please re-enter your name: ");
            read(0, name, 1000);
            break;

        //} else if (choice == 4) {
        //    break;
            
        } else {
            puts("Invalid choice!");
        }
    }
}