# CHALL 4
- `gcc -o chall4 -no-pie -z execstack chall4.c -static`
- ASLR should be OFF
- Bruteforce canary: byte-by-byte bruteforce by checking if the program crashes with a stack-smashing error'.
- Get shell: Buffer Overflow to overwrite return address and hijack control flow -> ret2shellcode.