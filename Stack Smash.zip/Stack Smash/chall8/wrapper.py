from pwn import *
from sys import argv
import _thread

# Helpers
e = context.binary = ELF('./chall8', checksec=False)

# Socket
HOST = "0.0.0.0"
PORT = int(argv[1])

def recvline(conn, n):
    data = b''
    while len(data) < n:
        b = conn.recv(1)
        if b == b'\n':
            return data
        if not b:
            return None
        data += b
    return data

def main(conn, addr):
    io = process(e.path)
    with conn:
        while True:
            log.success("Connection received")

            data = io.recvrepeat(0.05)
            conn.sendall(data)

            data = recvline(conn, 4096)
            io.send(data)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    while True:
        conn, addr = s.accept()
        _thread.start_new_thread(main, (conn, addr))
    s.close()