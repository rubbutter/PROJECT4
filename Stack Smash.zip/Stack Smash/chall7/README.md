# CHALL 7
- `gcc ./chall7.c -Wl,-z,relro,-z,now -fno-stack-protector -fno-pie -no-pie -o chall7`
- ROP without randomization and `system()` is NOT imported.
