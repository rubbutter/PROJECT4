#include <stdio.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
    char buf[1024];
    write(1, "Give me your shellcode: ", 24);
    read(0, buf, 1023);
    ((void (*)())buf)();
}
