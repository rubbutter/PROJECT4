#!/bin/bash

IMAGE_NAME=chall2

docker rm -f $(sudo docker ps -a | awk -v i="^$IMAGE_NAME.*" '{if($2~i){print$1}}');
docker build -t ${IMAGE_NAME} .
docker run -d --restart=always -p 1338:1338 ${IMAGE_NAME}
