# CHALL 8
- `nasm -f elf64 chall8.nasm; ld chall8.o -o chall8; rm chall8.o; execstack -c ./chall8`
- ASLR should be ON and PIE should be OFF
- ROP without libc and few gadgets available, invoke execve to get a shell.
